package com.team.hv.middleman.middleman;

/**
 * Created by Ben on 5/11/2014.
 */
public class Item {
    //Title, price, Description, location, high price, average price, low price
}
