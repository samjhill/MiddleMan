package com.team.hv.middleman.middleman;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.ErrorDialogFragment;
import com.google.android.gms.common.GooglePlayServicesUtil;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Created by Ben on 5/17/2014.
 */
public class CraigslistXmlReader extends AsyncTask<String, Integer, Boolean> {
    //http://cityname.craigslist.org/search/?areaID=126&catAbb=sss&query=' +itemtosearch+ '&sort=rel&format=rss

    @Override
    protected Boolean doInBackground(String...search){
        getCurrentLocation(search[0]);
        return true;
    }

    public void getCurrentLocation(String city) {
        String cityName = city;
        //get user location: 
    /*
        // Global constants
    /*
     * Define a request code to send to Google Play services
     * This code is returned in Activity.onActivityResult

        private final static int
                CONNECTION_FAILURE_RESOLUTION_REQUEST = 9000;
        
        // Define a DialogFragment that displays the error dialog
        public static class ErrorDialogFragment extends DialogFragment {
            // Global field to contain the error dialog
            private Dialog mDialog;
            // Default constructor. Sets the dialog field to null
            public ErrorDialogFragment() {
                super();
                mDialog = null;
            }
            // Set the dialog to display
            public void setDialog(Dialog dialog) {
                mDialog = dialog;
            }
            // Return a Dialog to the DialogFragment.
            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState) {
                return mDialog;
            }
        }
        
    /*
     * Handle results returned to the FragmentActivity
     * by Google Play services

        //@Override
        protected void onActivityResult(
        int requestCode, int resultCode, Intent data) {
            // Decide what to do based on the original request code
            switch (requestCode) {
                
                case CONNECTION_FAILURE_RESOLUTION_REQUEST :
            /*
             * If the result code is Activity.RESULT_OK, try
             * to connect again

                    switch (resultCode) {
                        case Activity.RESULT_OK :
                    /*
                     * Try the request again

                            
                            break;
                    }
                    
            }
        }
        
        private boolean servicesConnected() {
            // Check that Google Play services is available
            int resultCode =
                    GooglePlayServicesUtil.
                            isGooglePlayServicesAvailable(this);
            // If Google Play services is available
            if (ConnectionResult.SUCCESS == resultCode) {
                // In debug mode, log the status
                Log.d("Location Updates",
                        "Google Play services is available.");
                // Continue
                return true;
                // Google Play services was not available for some reason
            } else {
                // Get the error code
                int errorCode = connectionResult.getErrorCode();
                // Get the error dialog from Google Play services
                Dialog errorDialog = GooglePlayServicesUtil.getErrorDialog(
                        errorCode,
                        this,
                        CONNECTION_FAILURE_RESOLUTION_REQUEST);

                // If Google Play services can provide an error dialog
                if (errorDialog != null) {
                    // Create a new DialogFragment for the error dialog
                    ErrorDialogFragment errorFragment =
                            new ErrorDialogFragment();
                    // Set the dialog in the DialogFragment
                    errorFragment.setDialog(errorDialog);
                    // Show the error dialog in the DialogFragment
                    errorFragment.show(getSupportFragmentManager(),
                            "Location Updates");
                }
            }
        }
        */
    }

    function parseXml(xml) {
        //console.log(xml);
        $(xml).find("item").each(function() {
            var title = $(this).find("title").text();
            var link = $(this).find("link").text();
            //parse title down so it's not super long
            var prettyTitle = title.substr(0, title.indexOf("$"));
            //parse price out of title
            var price = title.substr(title.indexOf("$"), title.indexOf(" ") + 1);


            var priceInt = parseInt(price.substr(1));

            var items = new Array();
            //this will get rid of TRADE items
            if ( priceInt >= 0 ) {
                generatePost(link, priceInt, prettyTitle);
                items.push( new Object(link, priceInt, prettyTitle));

            }
            ////console.log(items);
            craigslistItems = items;
            clComplete = true;

        });
    }
}
